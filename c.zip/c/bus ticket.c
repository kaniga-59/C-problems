#include <stdio.h>

int main()
{
    char name[50];
    int age;
    int distance;
    int price, discount = 0,totalprice;

  
    scanf("%s", &name);

   
    scanf("%d", &age);

 
    scanf("%d", &distance);

   
    price = distance * 3;

   
    if (age < 5)
    {
        printf("Ticket Price: Free\n");
    }
    else if (age >= 60)
    {
        price = (distance * 3); 
        printf("Ticket Price: %d\n", price);
    }
    else
    {
        price = distance * 3;
        printf("Ticket Price: %d\n", price);
    }

    
    totalprice = price - discount;

    
  
    
  
  

    return 0;
}