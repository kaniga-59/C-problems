#include <stdio.h>
#include <string.h>

int main() {
    char mob[50];
    int i, len;

   
    scanf("%s", mob);

    len = strlen(mob);

    
    if (len != 10) {
        printf("Invalid\n");
        return 0;
    }

   
    if (mob[0] == '0') {
        printf("Invalid\n");
        return 0;
    }

   
    for (i = 0; i < len; i++)
    {
        if (mob[i] < '0' || mob[i] > '9') 
        {
            printf("Invalid\n");
            return 0;
        }
    }

   
    printf("Valid\n");
    return 0;
}
