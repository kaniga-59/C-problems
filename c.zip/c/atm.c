#include <stdio.h>

int main() {
    int choice;
    int amount;
    int balance = 1000;   
    
    while (1)
    {
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                printf("Balance: %d\n", balance);          
                break;

            case 2:
                printf("Enter amount to deposit: ");
                scanf("%d", &amount);
                if (amount > 0)
                {
                    balance += amount;                     
                    printf("Amount Deposited.\n");
                } 
                else 
                {
                    printf("Invalid deposit amount.\n");
                }
                break;

            case 3:
                printf("Enter amount to withdraw: ");
                scanf("%d", &amount);
                if (amount > balance) 
                {
                    printf("Error: Insufficient balance\n"); 
                } 
                else if (amount <= 0)
                {
                    printf("Invalid withdrawal amount.\n");
                } 
                else
                {
                    balance -= amount;                     
                    printf("Withdrawal successful.\n");
                }
                break;

            case 4:
                printf("Exiting...\n");                    
                return 0;

            default:
                printf("Invalid option! Please try again.\n"); 
                break;
        }
    }

    return 0;
}