#include <stdio.h>

int main() 
{
    int h[7], i;
    int total = 0;

   
    for (i = 0; i < 7; i++) 
    {
        scanf("%d", &h[i]);

        if (h[i] < 0)
        {              
            printf("Error\n");
            return 0;
        }
        if (h[i] > 24)
        {             
            printf("Very high\n");
            return 0;
        }
    }

    int salary = 0;

    for (i = 0; i < 7; i++) 
    {
        if (h[i] <= 8) 
        {
            salary += h[i] * 100;   
        }
        else
        {
            salary += (8 * 100) + (h[i] - 8) * 200;   
        }
    }

    printf("Salary = %d\n", salary);
    return 0;
}